package com.raw.loan.services;

import com.raw.loan.models.LoanModel;

import java.util.List;

public interface IScheduleService<T> {
    List<T> amortizationEmi(LoanModel model);
    List<T> amortizationDegressive(LoanModel model);
}
