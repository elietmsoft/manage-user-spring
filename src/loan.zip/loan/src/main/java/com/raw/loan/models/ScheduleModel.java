package com.raw.loan.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ScheduleModel {
    private int id; // Numéro de chaque ligne
    //private double creditAmount; // Montant crédit
    //private int tenure; // Nombre d'années
    //private double interestRate; // Taux d'Interêt annuel
    //private double monthlyInterestRate; // Taux d'interêt monsuel = interestRate / 12 * 100
    //private double monthlyPayment;
    private double interestPaid; // Les interêt à payer = creditAmount * monthlyInterestRate
    private double creditAmountPaid; // Montant crédit à payer par mois = monthyPayment - interestPaid
    private double balance; // Montant qui reste à payer après avoir déjà payé = creditAmount - creditAmountPaid

}
