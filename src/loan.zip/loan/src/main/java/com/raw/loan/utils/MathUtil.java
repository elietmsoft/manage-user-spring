package com.raw.loan.utils;

public class MathUtil {
    public static double around(double nbre){
        return Math.round(nbre * 100.0)/100.0;
    }
}
