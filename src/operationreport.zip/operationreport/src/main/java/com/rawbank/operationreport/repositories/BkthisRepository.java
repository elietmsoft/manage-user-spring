package com.rawbank.operationreport.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.rawbank.operationreport.entities.BkhisEntity;

public interface BkthisRepository extends JpaRepository<BkhisEntity, Long> {
	
	@Query("select e from BKHIS_DAILY e WHERE to_date(CAST(e.dco as date),'dd/mm/yy') >= to_date(?1,'dd/mm/yy') AND to_date(CAST(e.dco as date),'dd/mm/yy') <= to_date(?2,'dd/mm/yy') AND e.agenceId=?3")
	Optional<List<BkhisEntity>> findByDateTransaction(String dateFrom, String dateTo, long agenceId);
}
