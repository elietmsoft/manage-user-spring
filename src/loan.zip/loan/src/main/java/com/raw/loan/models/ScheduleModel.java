package com.raw.loan.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
public class ScheduleModel {
    private int id; // Numéro de chaque ligne
    private double interestPaid; // Les interêt à payer = creditAmount * monthlyInterestRate
    private double creditAmountPaid; // Montant crédit à payer par mois = monthyPayment - interestPaid
    private double balance; // Montant qui reste à payer après avoir déjà payé = creditAmount - creditAmountPaid

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getInterestPaid() {
        return interestPaid;
    }

    public void setInterestPaid(double interestPaid) {
        this.interestPaid = interestPaid;
    }

    public double getCreditAmountPaid() {
        return creditAmountPaid;
    }

    public void setCreditAmountPaid(double creditAmountPaid) {
        this.creditAmountPaid = creditAmountPaid;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
