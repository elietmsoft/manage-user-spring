package com.raw.loan.models;

import com.raw.loan.utils.DateUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
public class LoanModel {
    private double salary; // Salaire mensuel de la personne qui souscrit à un prêt
    private String type; // Type de prêt
    private String plan; // Plan de remboursement (EMI, Degressive)
    private int periodGrace; // Période de Grâce
    private boolean vatOnInterest; // TVA sur interêt (oui ou non) (yes or no) (true or false)
    private double rateVat; // Taux de la TVA
    private String currency; //Devise

    private double creditAmount; //Montant de crédit
    private int tenure; // Durée de remboursement
    private double interestRate; // Taux d'interêt
    private double facilityFees; // Frais d'établissement
    private double fileCharge; // Frais de dossier
    private double insurancePremium; // Prime d'assurance
    private String dateDisb = DateUtil.convertDateToString(new Date(),"dd/MM/yyyy");; // Date de décaissement
    private String dateFirst;//DateUtil.convertDateToString(DateUtil.getDateFirst(periodGrace),"dd/MM/yyyy"); //Date de premier remboursement
    private String dateLast; // Date de dernier remboursement


    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPlan() {
        return plan;
    }

    public void setPlan(String plan) {
        this.plan = plan;
    }

    public int getPeriodGrace() {
        return periodGrace;
    }

    public void setPeriodGrace(int periodGrace) {
        this.periodGrace = periodGrace;
    }

    public boolean isVatOnInterest() {
        return vatOnInterest;
    }

    public void setVatOnInterest(boolean vatOnInterest) {
        this.vatOnInterest = vatOnInterest;
    }

    public double getRateVat() {
        return rateVat;
    }

    public void setRateVat(double rateVat) {
        this.rateVat = rateVat;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public double getCreditAmount() {
        return creditAmount;
    }

    public void setCreditAmount(double creditAmount) {
        this.creditAmount = creditAmount;
    }

    public int getTenure() {
        return tenure;
    }

    public void setTenure(int tenure) {
        this.tenure = tenure;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public double getFacilityFees() {
        return facilityFees;
    }

    public void setFacilityFees(double facilityFees) {
        this.facilityFees = facilityFees;
    }

    public double getFileCharge() {
        return fileCharge;
    }

    public void setFileCharge(double fileCharge) {
        this.fileCharge = fileCharge;
    }

    public double getInsurancePremium() {
        return insurancePremium;
    }

    public void setInsurancePremium(double insurancePremium) {
        this.insurancePremium = insurancePremium;
    }

    public String getDateDisb() {
        return dateDisb;
    }

    public void setDateDisb(String dateDisb) {
        this.dateDisb = dateDisb;
    }

    public String getDateFirst() {
        return dateFirst;
    }

    public void setDateFirst(String dateFirst) {
        this.dateFirst = dateFirst;
    }

    public String getDateLast() {
        return dateLast;
    }

    public void setDateLast(String dateLast) {
        this.dateLast = dateLast;
    }

}
