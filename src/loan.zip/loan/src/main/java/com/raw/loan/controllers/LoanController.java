package com.raw.loan.controllers;

import com.raw.loan.models.LoanModel;
import com.raw.loan.models.ScheduleModel;
import com.raw.loan.services.ScheduleServiceImpl;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;

@Controller
@NoArgsConstructor
@AllArgsConstructor
public class LoanController {

    private ScheduleServiceImpl scheduleService = new ScheduleServiceImpl();

    @GetMapping(path = "/")
    public String index(Model model){
        LoanModel loan = new LoanModel();
        model.addAttribute("loan", loan);
        return "redirect:/home";
    }

    @GetMapping(path = "/home")
    public String home(Model model){
        LoanModel loan = new LoanModel();
        model.addAttribute("loan", loan);
        return "index";
    }

    @GetMapping(path = "/calcul")
    public String post(LoanModel loan, Model model){
        List<ScheduleModel> scheduleModelList =  scheduleService.amortizationEmi(loan);
        model.addAttribute("loan", loan);
        model.addAttribute("schedules",scheduleModelList);
        return "result";
    }

}
