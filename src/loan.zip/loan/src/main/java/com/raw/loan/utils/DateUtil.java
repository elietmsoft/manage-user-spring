package com.raw.loan.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {
	public static String convertDateToString(Date date,String formatAttendu) {
		SimpleDateFormat format = new SimpleDateFormat(formatAttendu);
		return format.format(date);
	}

	public static Date getDateFirst(int nbMonths){
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.MONTH,nbMonths);
		return cal.getTime();
	}
}
