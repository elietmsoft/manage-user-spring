package com.raw.loan.services;

import com.raw.loan.models.LoanModel;
import com.raw.loan.models.TreatmentModel;
import com.raw.loan.utils.DateUtil;
import com.raw.loan.utils.MathUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TreatmentServiceImpl implements IScheduleService<TreatmentModel>{
    @Override
    public List<TreatmentModel> amortizationEmi(LoanModel model) {
        List<TreatmentModel> list = new ArrayList<>();
       for (int i=1;i<=(model.getTenure()+1+model.getPeriodGrace());i++){
           TreatmentModel treatmentModel = new TreatmentModel();
           /** ID **/
           treatmentModel.setId(i);
           /** DATES*/
           treatmentModel.setDate(DateUtil.convertDateToString(DateUtil.getDateFirst(i-1),"dd/MM/yyyy"));
           /** No Of Dates */
           if ((i-1) <=0){
               /**** Les éléments de la première ligne */
               treatmentModel.setnDays(0);
               treatmentModel.setPrincipal(0);
               treatmentModel.setInterest(0);
               treatmentModel.setInterestVat(0);
               treatmentModel.setInsurancePremium(0);
               treatmentModel.setInsurancePremiumVat(0);
               treatmentModel.setFacilityFees(0);
               treatmentModel.setFacilityFeeVat(0);
               treatmentModel.setTotalAmountInstallment(0);
               treatmentModel.setPrincipalOutstanding(model.getCreditAmount());
           }
           else {
               /**************************Principal ***************/
               treatmentModel.setPrincipal(0);

               /*** Je dois mettre une function qui ira avec Periode de Grace **/
               double pOut = list.get(i-2).getPrincipalOutstanding() - treatmentModel.getPrincipal();
               treatmentModel.setPrincipalOutstanding(MathUtil.around(pOut));
               /******************** Fin ***************************************/

               Date from = DateUtil.getDateFirst(i-1);
               Date to = DateUtil.getDateFirst(i);
               long nDays = DateUtil.getDaysBetweenTwoMonths(from,to);
               treatmentModel.setnDays(nDays);

               /************* Interest *****/
               double principalOut = list.get(i-2).getPrincipalOutstanding();
               double interestRateByDay = model.getInterestRate()/36000;
               double result = principalOut * nDays * interestRateByDay;
               treatmentModel.setInterest(MathUtil.around(result));
               /************* Interest sur TVA *****/

               if(!model.isVatOnInterest()){
                   treatmentModel.setInterestVat(0);
               }
               else {
                   double interestVat = (model.getRateVat()/100) * result ;
                   treatmentModel.setInterestVat(MathUtil.around(interestVat));
               }

               /******************** Insurance Premium ****************/
               double valInsuranceP = ((model.getTenure() + model.getPeriodGrace()) * model.getCreditAmount() * (model.getInsurancePremium()/100))/model.getTenure();
               treatmentModel.setInsurancePremium(MathUtil.around(valInsuranceP));

               /********************* Insurance Premium TVA ************/
               double valInterInsP = (model.getRateVat()/100) * valInsuranceP;
               treatmentModel.setInsurancePremiumVat(MathUtil.around(valInterInsP));

               /*********************** Facility Fees ********************/
               double valFacilityF = (Math.ceil(((model.getTenure() + model.getPeriodGrace())/3)) * model.getCreditAmount() * (model.getFacilityFees()/100))/model.getTenure();
               treatmentModel.setFacilityFees(MathUtil.around(valFacilityF));

               /*********************** Facility Fees TVA ****************/
               double valInterFacilityF = (model.getRateVat()/100) * valFacilityF;
               treatmentModel.setFacilityFeeVat(MathUtil.around(valInterFacilityF));

               /****************** TotalAmountInstallment*************/
               double totalAmountInst = treatmentModel.getPrincipal() + treatmentModel.getInterest() + treatmentModel.getInterestVat() + treatmentModel.getInsurancePremium()+treatmentModel.getInsurancePremiumVat()+treatmentModel.getFacilityFees()+treatmentModel.getFacilityFeeVat();
               treatmentModel.setTotalAmountInstallment(MathUtil.around(totalAmountInst));
           }

           list.add(treatmentModel);
       }
       return list;
    }

    @Override
    public List<TreatmentModel> amortizationDegressive(LoanModel model) {
        return null;
    }
}
