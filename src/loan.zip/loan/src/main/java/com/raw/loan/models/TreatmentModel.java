package com.raw.loan.models;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
public class TreatmentModel {
    private int id;
    private String date;
    private long nDays;
    private double principal;
    private double interest;
    private double interestVat;
    private double insurancePremium;
    private double insurancePremiumVat;
    private double facilityFees;
    private double facilityFeeVat;
    private double totalAmountInstallment;
    private double principalOutstanding;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public long getnDays() {
        return nDays;
    }

    public void setnDays(long nDays) {
        this.nDays = nDays;
    }

    public double getPrincipal() {
        return principal;
    }

    public void setPrincipal(double principal) {
        this.principal = principal;
    }

    public double getInterest() {
        return interest;
    }

    public void setInterest(double interest) {
        this.interest = interest;
    }

    public double getInterestVat() {
        return interestVat;
    }

    public void setInterestVat(double interestVat) {
        this.interestVat = interestVat;
    }

    public double getInsurancePremium() {
        return insurancePremium;
    }

    public void setInsurancePremium(double insurancePremium) {
        this.insurancePremium = insurancePremium;
    }

    public double getInsurancePremiumVat() {
        return insurancePremiumVat;
    }

    public void setInsurancePremiumVat(double insurancePremiumVat) {
        this.insurancePremiumVat = insurancePremiumVat;
    }

    public double getFacilityFees() {
        return facilityFees;
    }

    public void setFacilityFees(double facilityFees) {
        this.facilityFees = facilityFees;
    }

    public double getFacilityFeeVat() {
        return facilityFeeVat;
    }

    public void setFacilityFeeVat(double facilityFeeVat) {
        this.facilityFeeVat = facilityFeeVat;
    }

    public double getTotalAmountInstallment() {
        return totalAmountInstallment;
    }

    public void setTotalAmountInstallment(double totalAmountInstallment) {
        this.totalAmountInstallment = totalAmountInstallment;
    }

    public double getPrincipalOutstanding() {
        return principalOutstanding;
    }

    public void setPrincipalOutstanding(double principalOutstanding) {
        this.principalOutstanding = principalOutstanding;
    }
}
