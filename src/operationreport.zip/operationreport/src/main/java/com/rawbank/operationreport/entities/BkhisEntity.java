package com.rawbank.operationreport.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity(name ="BKHIS_DAILY")
public class BkhisEntity {
	
	@Id
	@Column(name="ID")
	private long id;
	
	@Column(name="AGE")
	private String ageBk;
	
	@Column(name="DEV")
	private String devBk;
	
	@Column(name="NCP")
	private String ncpBk;
	
	@Column(name="SUF")
	private String sufBk;
	
	@Column(name="DCO")
	private Date dcoBk;
	
	@Column(name="OPE")
	private String opeBk;
	
	@Column(name="MVT")
	private String mvtBk;
	
	@Column(name="SER")
	private String serBk;
	
	@Column(name="DVA")
	private Date dvaBk;
	
	@Column(name="DIN")
	private Date dinBk;
	
	@Column(name="MON")
	private int monBk;
	
	@Column(name="SEN")
	private String senBk;
	
	@Column(name="LIB")
	private String libBk;
	
	@Column(name="EXO")
	private String exoBk;
	
	@Column(name="PIE")
	private String pieBk;
	
	@Column(name="DES1")
	private String des1Bk;
	
	@Column(name="DES2")
	private String des2Bk;
	
	@Column(name="DES3")
	private String des3Bk;
	
	@Column(name="DES4")
	private String des4Bk;
	
	@Column(name="DES5")
	private String des5Bk;
	
	@Column(name="UTI")
	private String utiBk;
	
	@Column(name="UTF")
	private String utfBk;
	
	@Column(name="UTA")
	private String utaBk;
	
	@Column(name="EVE")
	private String eveBk;
	
	@Column(name="AGEM")
	private String agemBk;
	
	@Column(name="DAG")
	private Date dagBk;
	
	@Column(name="NCC")
	private String nccBk;
	
	@Column(name="SUC")
	private String sucBk;
	
	@Column(name="CPL")
	private String cplBk;
	
	@Column(name="DDL")
	private Date ddlBk;
	
	@Column(name="RLET")
	private String rletBk;
	
	@Column(name="UTL")
	private String utlBk;
	
	@Column(name="MAR")
	private String marBk;
	
	@Column(name="DECH")
	private Date dechBk;
	
	@Column(name="AGSA")
	private String agsaBk;
	
	@Column(name="AGDE")
	private String agdeBk;
	
	@Column(name="DEVC")
	private String devcBk;
	
	@Column(name="MCTV")
	private int mctvBk;
	
	@Column(name="PIEO")
	private String pieoBk;
	
	@Column(name="IDEN")
	private String idenBk;
	
	@Column(name="NOSEQ")
	private int noseqBk;
	
	@Column(name="DEXA")
	private Date dexaBk;
	
	@Column(name="MODU")
	private String moduBk;
	
	@Column(name="REFDOS")
	private String refdosBk;
	
	@Column(name="LABEL")
	private String labelBk;
	
	@Column(name="NAT")
	private String natBk;
	
	@Column(name="ETA")
	private String etaBk;
	
	@Column(name="SCHEMA")
	private String schemaBk;
	
	@Column(name="CETICPT")
	private String ceticptBk;
	
	@Column(name="FUSION")
	private String fusionBk;
 
}