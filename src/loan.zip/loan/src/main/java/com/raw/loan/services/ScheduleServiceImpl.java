package com.raw.loan.services;

import com.raw.loan.models.LoanModel;
import com.raw.loan.models.ScheduleModel;
import com.raw.loan.utils.MathUtil;
import com.raw.loan.utils.PaymentUtil;

import java.util.ArrayList;
import java.util.List;
public class ScheduleServiceImpl implements IScheduleService<ScheduleModel>{
    @Override
    public List<ScheduleModel> amortizationEmi(LoanModel loan) {
        double interestPaid, principalPaid, newBalance;
        double monthlyInterestRate, monthlyPayment;
        List<ScheduleModel> list = new ArrayList<>();

        // Output monthly payment and total payment
        monthlyInterestRate = loan.getInterestRate()/ 1200;
        monthlyPayment      = PaymentUtil.getMonthly(loan.getCreditAmount(), monthlyInterestRate,loan.getTenure());

        for (int month = 1; month <= loan.getTenure(); month++) {
            // Compute amount paid and new balance for each payment period
            ScheduleModel scheduleModel = new ScheduleModel();
            interestPaid  = loan.getCreditAmount() * monthlyInterestRate;
            principalPaid = monthlyPayment - interestPaid;
            newBalance    = loan.getCreditAmount() - principalPaid;

            // Output the data item
            scheduleModel.setId(month);
            scheduleModel.setInterestPaid(MathUtil.around(interestPaid));
            scheduleModel.setCreditAmountPaid(MathUtil.around(principalPaid));
            scheduleModel.setBalance(MathUtil.around(newBalance));
            list.add(scheduleModel);
            // Update the balance
            loan.setCreditAmount(newBalance);
        }
        return list;
    }

    @Override
    public List<ScheduleModel> amortizationDegressive(LoanModel model) {
        return null;
    }
}
