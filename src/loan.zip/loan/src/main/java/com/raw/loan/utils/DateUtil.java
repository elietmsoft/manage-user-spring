package com.raw.loan.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class DateUtil {
	public static String convertDateToString(Date date,String formatAttendu) {
		SimpleDateFormat format = new SimpleDateFormat(formatAttendu);
		return format.format(date);
	}

	public static Date convertStringToDate(String date) {
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE);
		try {
			return format.parse(date);
		} catch (ParseException e) {
			throw new RuntimeException(e);
		}
	}

	public static Date getDateFirst(int nbMonths){
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.MONTH,nbMonths);
		return cal.getTime();
	}

	public static int compareToDates(Date first, Date actual){
		return actual.compareTo(first);
	}

	public static long getDaysBetweenTwoMonths(Date fromDate, Date toDate){
		long diffInMillies = Math.abs(toDate.getTime() - fromDate.getTime());
		long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
		return diff;
	}
}
