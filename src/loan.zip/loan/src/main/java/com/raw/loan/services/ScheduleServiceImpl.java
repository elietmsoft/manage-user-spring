package com.raw.loan.services;

import com.raw.loan.models.LoanModel;
import com.raw.loan.models.ScheduleModel;
import com.raw.loan.utils.PaymentUtil;

import java.util.ArrayList;
import java.util.List;

public class ScheduleServiceImpl implements IScheduleService<ScheduleModel>{
    @Override
    public List<ScheduleModel> amortizationEmi(LoanModel model) {
        double interestPaid, principalPaid, newBalance;
        double monthlyInterestRate, monthlyPayment;
        List<ScheduleModel> list = new ArrayList<>();

        // Output monthly payment and total payment
        monthlyInterestRate = model.getInterestRate()/ 12*100;
        monthlyPayment      = PaymentUtil.getMonthly(model.getCreditAmount(), monthlyInterestRate,model.getTenure());

        for (int month = 1; month <= model.getTenure(); month++) {
            // Compute amount paid and new balance for each payment period
            ScheduleModel scheduleModel = new ScheduleModel();
            interestPaid  = model.getCreditAmount() * monthlyInterestRate;
            System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            System.out.println("CreditAmount->"+model.getCreditAmount());
            System.out.println("interestPaid->"+model.getCreditAmount()*monthlyInterestRate);
            System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            principalPaid = monthlyPayment - interestPaid;
            newBalance    = model.getCreditAmount() - principalPaid;

            // Output the data item
            scheduleModel.setId(month);
            scheduleModel.setInterestPaid(interestPaid);
            scheduleModel.setCreditAmountPaid(principalPaid);
            scheduleModel.setBalance(newBalance);
            list.add(scheduleModel);
            // Update the balance
            model.setCreditAmount(newBalance);
        }
        return list;
    }

    @Override
    public List<ScheduleModel> amortizationDegressive(LoanModel model) {
        return null;
    }
}
