package com.raw.loan.utils;

public class PaymentUtil {

    /**
     * @param creditAmount
     * @param monthlyInterestRate déja divisé par 100 pour avoir le taux = monthlyInterestRate /= 100;  // e.g. 5% => 0.05
     * @param tenure en mois déja si c'était en année, on allait multiplier par 12
     * @return
     */
    public static double getMonthly(double creditAmount, double monthlyInterestRate, int tenure) {
        return ((creditAmount * monthlyInterestRate) /
                ( 1 - 1 / Math.pow(1 + monthlyInterestRate, tenure) ));
    }
}
