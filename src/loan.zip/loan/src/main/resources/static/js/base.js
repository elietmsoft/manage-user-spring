const data = {
	"express_credit":{
		"interest_rate":{
			"currency_cdf":45,
			"currency_usd":null,
			"isYear":true
		},
		"credit_amount":{
			"currency_cdf":{
				"min":null,
				"max":null
			},
			"currency_usd":{
				"min":450,
				"max":30000
			}
		},
		"tenure":{
			"min":0,
			"max":60
		},
		"facility_fees":1,
		"file_charge":{
			"value":2,
			"min":{
				"currency_cdf":null,
				"currency_usd":50
			}
		}
	},
    "senior_credit":{
		"interest_rate":{
			"currency_cdf":4,
			"currency_usd":3,
			"isYear":false
		},
		"credit_amount":{
			"currency_cdf":{
				"min":null,
				"max":null
			},
			"currency_usd":{
				"min":10000,
				"max":null
			}
		},
		"tenure":{
			"min":0,
			"max":24
		},
		"facility_fees":0.5,
		"file_charge":{
			"value":2,
			"min":{
				"currency_cdf":null,
				"currency_usd":50
			}
		}
	},
	"leopard_credit":{
		"interest_rate":{
			"currency_cdf":3.75,
			"currency_usd":1.5,
			"isYear":false
		},
		"credit_amount":{
			"currency_cdf":{
				"min":null,
				"max":null
			},
			"currency_usd":{
				"min":70,
				"max":10000
			}
		},
		"tenure":{
			"min":0,
			"max":15
		},
		"facility_fees":0.5,
		"file_charge":{
			"value":1,
			"min":{
				"currency_cdf":null,
				"currency_usd":10
			}
		}
	},
	"etude_credit":{
		"interest_rate":{
			"currency_cdf":3.75,
			"currency_usd":2.5,
			"isYear":false
		},
		"credit_amount":{
			"currency_cdf":{
				"min":null,
				"max":null
			},
			"currency_usd":{
				"min":150,
				"max":5000
			}
		},
		"tenure":{
			"min":0,
			"max":13
		},
		"facility_fees":0.5,
		"file_charge":{
			"value":1,
			"min":{
				"currency_cdf":null,
				"currency_usd":25
			}
		}
	},
	"okaz_auto_credit":{
		"interest_rate":{
			"currency_cdf":45,
			"currency_usd":12,
			"isYear":true
		},
		"credit_amount":{
			"currency_cdf":{
				"min":null,
				"max":null
			},
			"currency_usd":{
				"min":4000,
				"max":30000
			}
		},
		"tenure":{
			"min":13,
			"max":60
		},
		"facility_fees":1,
		"file_charge":{
			"value":2,
			"min":{
				"currency_cdf":null,
				"currency_usd":200
			}
		}
	},
	"easy_shop_credit":{
		"interest_rate":{
			"currency_cdf":3.75,
			"currency_usd":1.75,
			"isYear":false
		},
		"credit_amount":{
			"currency_cdf":{
				"min":null,
				"max":null
			},
			"currency_usd":{
				"min":200,
				"max":10000
			}
		},
		"tenure":{
			"min":0,
			"max":24
		},
		"facility_fees":0.5,
		"file_charge":{
			"value":1,
			"min":{
				"currency_cdf":null,
				"currency_usd":15
			}
		}
	},
	"moto_credit":{
		"interest_rate":{
			"currency_cdf":3.75,
			"currency_usd":1.75,
			"isYear":false
		},
		"credit_amount":{
			"currency_cdf":{
				"min":null,
				"max":null
			},
			"currency_usd":{
				"min":800,
				"max":5000
			}
		},
		"tenure":{
			"min":0,
			"max":24
		},
		"facility_fees":0.5,
		"file_charge":{
			"value":1,
			"min":{
				"currency_cdf":null,
				"currency_usd":15
			}
		}
	},
	"moto_plus_credit":{
		"interest_rate":{
			"currency_cdf":3.75,
			"currency_usd":3.5,
			"isYear":false
		},
		"credit_amount":{
			"currency_cdf":{
				"min":null,
				"max":null
			},
			"currency_usd":{
				"min":0,
				"max":4500
			}
		},
		"tenure":{
			"min":0,
			"max":13
		},
		"facility_fees":0.5,
		"file_charge":{
			"value":1,
			"min":{
				"currency_cdf":null,
				"currency_usd":15
			}
		}
	},
	"voiture_credit":{
		"interest_rate":{
			"currency_cdf":45,
			"currency_usd":12,
			"isYear":true
		},
		"credit_amount":{
			"currency_cdf":{
				"min":null,
				"max":null
			},
			"currency_usd":{
				"min":8000,
				"max":50000
			}
		},
		"tenure":{
			"min":36,
			"max":60
		},
		"facility_fees":1,
		"file_charge":{
			"value":1,
			"min":{
				"currency_cdf":null,
				"currency_usd":200
			}
		}
	},
	"easy_fly_credit":{
		"interest_rate":{
			"currency_cdf":3.75,
			"currency_usd":1.75,
			"isYear":false
		},
		"credit_amount":{
			"currency_cdf":{
				"min":null,
				"max":null
			},
			"currency_usd":{
				"min":200,
				"max":10000
			}
		},
		"tenure":{
			"min":13,
			"max":24
		},
		"facility_fees":0.5,
		"file_charge":{
			"value":1,
			"min":{
				"currency_cdf":null,
				"currency_usd":15
			}
		}
	},
	"easy_energy_credit":{
		"interest_rate":{
			"currency_cdf":3.75,
			"currency_usd":1.75,
			"isYear":false
		},
		"credit_amount":{
			"currency_cdf":{
				"min":null,
				"max":null
			},
			"currency_usd":{
				"min":150,
				"max":10000
			}
		},
		"tenure":{
			"min":0,
			"max":24
		},
		"facility_fees":0.5,
		"file_charge":{
			"value":1,
			"min":{
				"currency_cdf":null,
				"currency_usd":15
			}
		}
	},
	"schoolap_credit":{
		"interest_rate":{
			"currency_cdf":3.25,
			"currency_usd":2,
			"isYear":false
		},
		"credit_amount":{
			"currency_cdf":{
				"min":null,
				"max":null
			},
			"currency_usd":{
				"min":150,
				"max":1500
			}
		},
		"tenure":{
			"min":13,
			"max":13
		},
		"facility_fees":0.5,
		"file_charge":{
			"value":1,
			"min":{
				"currency_cdf":null,
				"currency_usd":25
			}
		}
	},
	"other_credit":{
		"interest_rate":{
			"currency_cdf":0,
			"currency_usd":0,
			"isYear":true
		},
		"credit_amount":{
			"currency_cdf":{
				"min":null,
				"max":null
			},
			"currency_usd":{
				"min":null,
				"max":null
			}
		},
		"tenure":{
			"min":0,
			"max":null
		},
		"facility_fees":0.5,
		"file_charge":{
			"value":null,
			"min":{
				"currency_cdf":null,
				"currency_usd":null
			}
		}
	}
}

/************************************************************** Declarations variables *************************************************/

	var inputPeriod = document.getElementById("inputGrace");
	var inputTenure = document.getElementById("inputTenure");
	var inputInterestRate = document.getElementById("inputInterestRate");
	var inputCreditAmount = document.getElementById("inputAmount");
	var inputFacilityFees = document.getElementById("inputFees");
	var inputFileCharge = document.getElementById("inputFileCharge");
	
	var selectLoanType = document.getElementById("selectLoanType");
	var selectPlan = document.getElementById("selectPlan");
	var selectCurrency = document.getElementById("selectCurrency");
	
	var dateDisb = document.getElementById("inputDateDisb");
	var dateFirst = document.getElementById("inputDateFirst");
	var dateLast = document.getElementById("inputDateLast");

/**************************************************************** End Declarations *****************************************************/


/********************************************************* Functions & Procedure *******************************************************/

  function funcSwitchInterestRate(loan,currency){
	   return data[loan]["interest_rate"][currency]; //return number
  }
  
  function funcSwitchCreditAmount(loan,currency){
	   return data[loan]["credit_amount"][currency]; //return {min:0,max:1}
  }
  
  function funcSwitchTenure(loan){
	   return data[loan]["tenure"]; //return {min:0,max:1}
  }
  
  function funcSwitchFacilityFees(loan){
	   return data[loan]["facility_fees"]; //return number
  }
  
  function funcSwitchFileCharge(loan){
	   return data[loan]["file_charge"]["value"]; //return number
  }
  
  function funcSwitchFileChargeIfLess(loan,currency){
	   return data[loan]["file_charge"]["min"][currency]; //return number
  }

/********************************************************* End Functions & Procedure  **************************************************/


/**************************************************************** Some Functions for Treatments ****************************************/

	function splitDate(date){
		return date.split("/");
	}
	
	function addMonths(ds, months) {
		var dp = splitDate(ds);
	    var date = new Date(dp[2],dp[1],dp[0]);
	    date.setMonth(date.getMonth() + +months);
	    return date;
	}
	
	function treatLoanType(text){
	   const currency = selectCurrency.options[selectCurrency.selectedIndex].value;
	   let interestRate = funcSwitchInterestRate(text,currency);
	   let creditAmount = funcSwitchCreditAmount(text,currency);
	   let tenure = funcSwitchTenure(text);
	   let facilityFees = funcSwitchFacilityFees(text);
	   let fileCharge = funcSwitchFileCharge(text);
	   
	   /** Affectation des valeurs */
	   inputInterestRate.value = interestRate;
	   
	   inputCreditAmount.min = creditAmount["min"];
	   inputCreditAmount.max = creditAmount["max"];
	   
	   inputTenure.min = tenure["min"];
	   inputTenure.max = tenure["max"];
	   
	   inputFacilityFees.value = facilityFees;
	   inputFileCharge.value = fileCharge;
	}

/*************************************************************** End Some Functions for Treatments *************************************/


/****************************************** Functions on Event SelectChange *******************************************/

	onChangeSelectLoan = (e) =>{
	   const text = selectLoanType.options[selectLoanType.selectedIndex].value;
	   treatLoanType(text);
	}
	
	onChangeSelectCurrency = (e) =>{
	   const loan = selectLoanType.options[selectLoanType.selectedIndex].value;
	   treatLoanType(loan);
	}

	 onChange = (e)=>{
       console.log("DATA PERIODE",e.target["name"])
     }

/******************************************** End Functions on Event SelectChange **************************************/



/************************************************************** Events ***************************************************************/

	inputPeriod.addEventListener("input",onChange)
	inputTenure.addEventListener("input",onChange)
	
	selectLoanType.addEventListener("change",onChangeSelectLoan)
	selectCurrency.addEventListener("change",onChangeSelectCurrency)

/************************************************************* End Events *************************************************************/
