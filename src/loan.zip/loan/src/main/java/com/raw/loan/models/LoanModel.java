package com.raw.loan.models;

import com.raw.loan.utils.DateUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class LoanModel {
    private double salary; // Salaire mensuel de la personne qui souscrit à un prêt
    private String type; // Type de prêt
    private String plan; // Plan de remboursement (EMI, Degressive)
    private int periodGrace; // Période de Grâce
    private boolean vatOnInterest; // TVA sur interêt (oui ou non) (yes or no) (true or false)
    private double rateVat; // Taux de la TVA
    private String currency; //Devise
    private double creditAmount; //Montant de crédit
    private int tenure; // Durée de remboursement
    private double interestRate; // Taux d'interêt
    private double facilityFees; // Frais d'établissement
    private double fileCharge; // Frais de dossier
    private double insurancePremium; // Prime d'assurance
    private String dateDisb = DateUtil.convertDateToString(new Date(), "dd/MM/yyyy"); // Date de décaissement
    private String dateFirst; //DateUtil.convertDateToString(DateUtil.getDateFirst(periodGrace),"dd/MM/yyyy");Date de premier remboursement
    private String dateLast; // Date de dernier remboursement

}
