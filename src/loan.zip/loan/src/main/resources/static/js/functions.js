/*
function(e){
	let dtDisb = dateDisb.value;
	let period = e.target.value;
	let dtFirst = addMonths(dtDisb,period);
	dateFirst.value = dtFirst.toLocaleDateString();
}
function(e){
	let dtFirst = dateFirst.value;
	let tenure = e.target.value - 2;
	let dtLast = addMonths(dtFirst,tenure);
	dateLast.value = dtLast.toLocaleDateString();
}

 /*switch(text){
		case "express_credit":
		   treatCreditExpress(text)
		break;
		case "senior_credit":
		   console.log(`Je suis ${text}`)
		break;
		case "leopard_credit":
		   console.log(`Je suis ${text}`)
		break;
		case "etude_credit":
			console.log(`Je suis ${text}`)
		break;
		case "okaz_auto_credit":
			console.log(`Je suis ${text}`)
		break;
		case "easy_shop_credit":
			console.log(`Je suis ${text}`)
		break;
		case "moto_credit":
			console.log(`Je suis ${text}`)
		break;
		case "moto_plus_credit":
			console.log(`Je suis ${text}`)
		break;
		case "voiture_credit":
			console.log(`Je suis ${text}`)
		break;
		case "easy_fly_credit":
			console.log(`Je suis ${text}`)
		break;
		case "easy_energy_credit":
			console.log(`Je suis ${text}`)
		break;
		case "schoolap_credit":
			console.log(`Je suis ${text}`)
		break;
		case "other_credit":
			console.log(`Je suis ${text}`)
		break;
	  }*/
	  
	  function onChange(e){
		console.log("DATA PERIODE",e.target["name"])
	}